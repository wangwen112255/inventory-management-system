<?php

/**
 * @title 基础参数
 */

return [
  'company' => '北京为纳百川商贸有限公司',
  'title' => '进销存',
  'page_size' => '10',
];