{extend name="base:base" /}{block name="body"}  








{/block}