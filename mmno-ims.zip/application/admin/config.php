<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

return [
       
    'view_replace_str' => [
        '__PUBLIC__' => APP_URL . '',
        '__STATIC__' => APP_URL . '/static',
    ],
    
];