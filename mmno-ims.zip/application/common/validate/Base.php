<?php

namespace app\common\validate;

use think\Validate;

class Base extends Validate {
    
}
