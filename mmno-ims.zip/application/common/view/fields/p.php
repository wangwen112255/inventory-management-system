 <div class="form-group">
            <label class="col-sm-2 control-label"><?php echo $field['title'] ?></label>
            <div class="col-sm-6">



                <p class="form-control-static"> <?php echo $field['description'] ?> </p>



            </div>
        </div>