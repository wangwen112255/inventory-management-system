 <input type="hidden" name="<?php echo $field['name'] ?>" value="<?php echo $field['options']; ?>">

