<div class="form-group">
    <label class="col-sm-2 control-label"><?php echo $field['title'] ?></label>
    <div class="col-sm-6" id="<?php echo $field['name'] ?>">
        <label>
            <select  class="form-control"  name="province"></select>
        </label>
        <label>
            <select  class="form-control"  name="city"></select>
        </label>
        <label>
            <select  class="form-control"  name="area"></select>
        </label>
    </div>
</div>