
<div class="form-group">
    <label class="col-sm-2 control-label"><?php echo $field['title'] ?></label>
    <div class="col-sm-6 form-inline">
        <input type="text" class="form-control form_datetime" id="<?php echo $field['name']; ?>" name="<?php echo $field['name']; ?>" value="<?php echo $field['result']; ?>" placeholder="<?php echo $field['title'] ?>">

    </div><div class="check-tips"><?php echo $field['description'] ?></div>
</div>

