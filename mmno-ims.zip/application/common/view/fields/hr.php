<div class="form-group">
    <div class="col-sm-offset-2 col-sm-6">
        <hr />
    </div>
</div>
