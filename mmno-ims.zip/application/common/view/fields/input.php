<div class="form-group">
    <label class="col-sm-2 control-label"><?php echo $field['title'] ?></label>
    <div class="col-sm-6">
        <input type="text" class="form-control" name="<?php echo $field['name'] ?>" value="<?php echo $field['result'] ?>" />
    </div>
    <div class="check-tips"><?php echo $field['description'] ?></div>
</div>